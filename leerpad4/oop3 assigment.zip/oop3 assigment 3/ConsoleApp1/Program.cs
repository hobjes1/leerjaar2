﻿//using System;
using System.Collections.Generic;

abstract class Pokemon
{
    public string Name { get; protected set; }
    public string Strength { get; protected set; }
    public string Weakness { get; protected set; }

    protected Pokemon(string name, string strength, string weakness)
    {
        Name = name;
        Strength = strength;
        Weakness = weakness;
    }

    public abstract void BattleCry();
}

class Squirtle : Pokemon
{
    public Squirtle(string name) : base(name, "water", "leaf") { }

    public override void BattleCry()
    {
        Console.WriteLine($"{Name} says: Squirt, squirt!");
    }
}

class Bulbasaur : Pokemon
{
    public Bulbasaur(string name) : base(name, "grass", "fire") { }

    public override void BattleCry()
    {
        Console.WriteLine($"{Name} says: Bulba, bulba!");
    }
}

class Charmander : Pokemon
{
    public Charmander(string name) : base(name, "fire", "water") { }

    public override void BattleCry()
    {
        Console.WriteLine($"{Name} says: Char, char!");
    }
}

class Trainer
{
    public string TrainerName { get; private set; }
    private Queue<Pokemon> belt;

    public Trainer(string name)
    {
        TrainerName = name;
        belt = new Queue<Pokemon>();
        belt.Enqueue(new Squirtle("Squirtle"));
        belt.Enqueue(new Squirtle("Squirtle"));
        belt.Enqueue(new Bulbasaur("Bulbasaur"));
        belt.Enqueue(new Bulbasaur("Bulbasaur"));
        belt.Enqueue(new Charmander("Charmander"));
        belt.Enqueue(new Charmander("Charmander"));
    }

    public void ThrowPokemon()
    {
        var pokemon = belt.Dequeue();
        Console.WriteLine($"{TrainerName} throws {pokemon.Name}.");
        pokemon.BattleCry();
    }

    public void ReturnPokemon()
    {
        Console.WriteLine($"{TrainerName} returns the pokemon to its pokeball.");
    }

    public bool HasPokemonLeft()
    {
        return belt.Count > 0;
    }
}

class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Pokemon Battle Simulator");
            Console.WriteLine("1. Start");
            Console.WriteLine("2. Quit");
            Console.Write("Enter your choice: ");
            int choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                Console.Write("Enter name for Trainer 1: ");
                string trainer1Name = Console.ReadLine();
                Console.Write("Enter name for Trainer 2: ");
                string trainer2Name = Console.ReadLine();

                Trainer trainer1 = new Trainer(trainer1Name);
                Trainer trainer2 = new Trainer(trainer2Name);

                while (trainer1.HasPokemonLeft() && trainer2.HasPokemonLeft())
                {
                    trainer1.ThrowPokemon();
                    trainer2.ThrowPokemon();
                    trainer1.ReturnPokemon();
                    trainer2.ReturnPokemon();
                }

                Console.WriteLine("All pokeballs have been used.");
            }
            else if (choice == 2)
            {
                Console.WriteLine("Goodbye!");
                break;
            }
            else
            {
                Console.WriteLine("Invalid choice. Please select again.");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        // Game loop
        while (true)
        {
            Console.WriteLine("Pokemon Battle Simulator");
            Console.WriteLine("1. Start");
            Console.WriteLine("2. Quit");
            Console.Write("Enter your choice: ");
            int choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                Console.Write("Enter name for Trainer 1: ");
                string trainer1Name = Console.ReadLine();
                Console.Write("Enter name for Trainer 2: ");
                string trainer2Name = Console.ReadLine();

                Trainer trainer1 = new Trainer(trainer1Name);
                Trainer trainer2 = new Trainer(trainer2Name);

                while (!trainer1.AreAllPokeballsEmpty() && !trainer2.AreAllPokeballsEmpty())
                {
                    Console.WriteLine($"{trainer1.GetName()} throws a pokeball...");
                    trainer1.ThrowPokeball();
                    Console.WriteLine($"{trainer2.GetName()} throws a pokeball...");
                    trainer2.ThrowPokeball();

                    Console.WriteLine($"{trainer1.GetName()} returns the charmander.");
                    trainer1.ReturnCharmander();
                    Console.WriteLine($"{trainer2.GetName()} returns the charmander.");
                    trainer2.ReturnCharmander();
                }

                Console.WriteLine("All pokeballs have been used.");
            }
            else if (choice == 2)
            {
                Console.WriteLine("Goodbye!");
                break;
            }
            else
            {
                Console.WriteLine("Invalid choice. Please select again.");
            }
        }
    }
}

class Pokeball
{
    private bool isOpen = false;
    private string containedPokemonName;

    public bool IsOpen
    {
        get { return isOpen; }
    }

    public string ContainedPokemonName
    {
        get { return containedPokemonName; }
    }

    public void Open(string pokemonName)
    {
        isOpen = true;
        containedPokemonName = pokemonName;
        Console.WriteLine($"Charmander appears and says '{pokemonName}'!");
    }

    public void Close()
    {
        isOpen = false;
        containedPokemonName = null;
    }
}

class Trainer
{
    private string trainerFullName;
    private List<Pokeball> trainerPokeballs = new List<Pokeball>();

    public Trainer(string name)
    {
        trainerFullName = name;

        for (int i = 0; i < 6; i++)
        {
            trainerPokeballs.Add(new Pokeball());
        }
    }

    public string GetName()
    {
        return trainerFullName;
    }

    public void ThrowPokeball()
    {
        foreach (var ball in trainerPokeballs)
        {
            if (!ball.IsOpen)
            {
                ball.Open("Charmander");
                break;
            }
        }
    }

    public void ReturnCharmander()
    {
        foreach (var ball in trainerPokeballs)
        {
            if (ball.IsOpen)
            {
                ball.Close();
                break;
            }
        }
    }

    public bool AreAllPokeballsEmpty()
    {
        foreach (var ball in trainerPokeballs)
        {
            if (!ball.IsOpen)
            {
                return false;
            }
        }
        return true;
    }
}
